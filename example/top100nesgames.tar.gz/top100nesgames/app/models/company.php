<?php

class Company extends AppModel {
    var $name = 'Company';

    var $validate = array(
            'name' => array(
                            'rule' => 'notEmpty'
            ),
            'body' => array(
                            'rule' => 'notEmpty'
            )
    );

    var $hasMany = array(
        'Game' => array(
            'className'     => 'Game',
            'dependent'=> true
        )
    );

}

?>
