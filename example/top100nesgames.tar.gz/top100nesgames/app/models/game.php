<?php

class Game extends AppModel {
    var $name = 'Game';

    var $validate = array(
            'name' => array(
                            'rule' => 'notEmpty'
            ),
            'body' => array(
                            'rule' => 'notEmpty'
            )
    );

    var $belongsTo = array(
            'Company' => array(
                            'className'    => 'Company'
            )
    );

    var $hasMany = array('Rating' =>
            array('className'   => 'Rating',
                            'foreignKey'  => 'model_id',
                            'conditions' => array('Rating.model' => 'Game'),
                            'dependent'   => true,
                            'exclusive'   => true
            )
    );

}

?>