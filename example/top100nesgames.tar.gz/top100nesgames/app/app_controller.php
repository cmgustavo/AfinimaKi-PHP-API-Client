<?php
/*
 * Top 100 NES Games
 */



/*
 * Import Facebook API library
 * For more details about this implementation in CakePHP please visit:
 * http://cutfromthenorth.com/integrating-facebook-connect-with-cakephps-auth-component/
 */
App::import('Vendor', 'facebook', array('file' => 'facebook'.DS.'facebook.php'));

class AppController extends Controller {
    var $uses = array ('User');
    var $components = array('Auth', 'RequestHandler', 'Cookie');
    var $helpers = array('Javascript', 'Ajax');

    var $facebook;

    // Your FB API Key >> /app/view/layout/default.ctp require this value too.
    var $__fbApiKey = 'your_api_key';
    // Your FB Secret Key
    var $__fbSecret = 'your_secret_key';

    function __construct() {
        parent::__construct();

        // Prevent the 'Undefined index: facebook_config' notice from being thrown.
        $GLOBALS['facebook_config']['debug'] = NULL;

        // Create a Facebook client API object.
        $this->facebook = new Facebook($this->__fbApiKey, $this->__fbSecret);
    }

    function beforeFilter() {
        $this->Auth->allow('index', 'recommend', 'all_games', 'view', 'estimate_rate');
        $this->Auth->logoutRedirect = array('controller' => 'games', 'action' => 'index');

        //check to see if user is signed in with facebook
        $this->__checkFBStatus();

        $this->set('rates', $this->Session->read('rates'));
        
        if ($this->Auth->user()) {
            $this->set('user', $this->Auth->user());
            $this->Session->write('User.id', $this->Auth->user('id'));
            $this->Session->write('User.email', hash('sha256', $this->Auth->user('email')));
        }
        
    }

    private function __checkFBStatus() {
        //check to see if a user is not logged in, but a facebook user_id is set
        if(!$this->Auth->User() && $this->facebook->get_loggedin_user()){
            //see if this facebook id is in the User database; if not, create the user using their fbid hashed as their password
            $user_record =
                    $this->User->find('first', array(
                    'conditions' => array('fbid' => $this->facebook->get_loggedin_user()),
                    'fields' => array('User.fbid', 'User.fbpassword', 'User.password'),
                    'contain' => array()
            ));

            //create new user
            if(empty($user_record)):
                $user_record['fbid'] = $this->facebook->get_loggedin_user();
                $user_record['fbpassword'] = $this->__randomString();
                $user_record['password'] = $this->Auth->password($user_record['fbpassword']);
                $user_record['email'] = $user_record['fbid'];

                $this->User->create();
                $this->User->save($user_record);
            endif;

            //change the Auth fields
            $this->Auth->fields = array('username' => 'fbid', 'password' => 'password');

            //log in the user with facebook credentials
            $this->Auth->login($user_record);
        }

    }

    private function __randomString($minlength = 20, $maxlength = 20, $useupper = true, $usespecial = false, $usenumbers = true) {
        $charset = "abcdefghijklmnopqrstuvwxyz";
        if ($useupper) $charset .= "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
        if ($usenumbers) $charset .= "0123456789";
        if ($usespecial) $charset .= "~@#$%^*()_+-={}|][";
        if ($minlength > $maxlength) $length = mt_rand ($maxlength, $minlength);
        else $length = mt_rand ($minlength, $maxlength);
        $key = '';
        for ($i=0; $i<$length; $i++) {
            $key .= $charset[(mt_rand(0,(strlen($charset)-1)))];
        }
        return $key;
    }

}
?>