<?php
class UsersController extends AppController {

    var $name = 'Users';

    function login() {
        if (!$this->Auth->user() || !$this->facebook->get_loggedin_user()) {
            $facebook_id = $this->facebook->require_login();
        }
        $this->redirect(array('controller' => 'games', 'action' => 'index'));
    }

    function logout() {
        $this->Session->destroy();
        $this->redirect($this->Auth->logout());
    }

}
?>