<?php
/*
 * Top 100 NES Games
 */

// Import AfinimaKi API library
App::import('Vendor', 'afinimaki', array('file' => 'afinimaki'.DS.'AfinimaKi.php'));

class GamesController extends AppController {

    var $name = 'Games';

    // AfinimaKi
    var $afinimaki;

    // Get your AfinimaKi API Key
    var $api_key = 'your_api_key';
    // Get your AfinimaKi API Secrect
    var $api_secret = 'your_api_secret';

    /*
     * AfinimaKi server params
     */
    var $host = ''; // Required
    var $port = ''; // 8081
    var $path = ''; // /RPC2
    /*
     * Debug log
     * 0 : without log
     * 1 : xml-rpc structure only
     * 2 : full xml-rpc log
     */
    var $debug = 0;

    function beforeFilter() {
        parent::beforeFilter();

        /*
         * Class AfinimaKi - Check params above
         */
        $this->afinimaki = new AfinimaKi(array(
                        'api_key' => $this->api_key,
                        'api_secret' => $this->api_secret,
                        'debug' => $this->debug,
                        'host' => $this->host,
                        'port' => $this->port,
                        'path' => $this->path)
                );
    }

    /*
     * It apps use call ajax for get info. Index method is not used.
     * I only set title "Home".
     */
    function index() {
        $this->pageTitle = 'Home';
        if ($this->api_key == '' or $this->api_secret == '' or $this->host == '' or $this->port == '' or $this->path == '') {
            $this->set('error', 'Please, complete data connection.');
        }
    }

    /*
     * Get recommend items through AfinimaKi Engine
     */
    function recommend() {
        $this->layout = 'ajax';
        $recommendations = $this->get_recommendations($this->Session->read('User.email'));
        $this->set('recommendations', $recommendations);
        $this->render('/elements/recommend');
    }

    /*
     * Get all games. If loggin, get only games not recommended above.
     */
    function all_games() {
        $this->layout = 'ajax';
        if ($this->Session->read('rates') == 3) {
            $this->Session->write('rates', 0);
        }

        // Get games with its companies names.
        $this->Game->recursive = 0;

        /*
         * Condition select to paginate element that isn't recommended.
         */
        $conditions = '';
        if ($this->Session->read('User.id')) {
            $recommendations = $this->get_recommendations($this->Session->read('User.email'));

            if (!empty($recommendations)) {
                foreach ($recommendations as $items) {
                    foreach ($items->me as $item) {
                        $conditions .= 'Game.id != ' . $item[0]->me['i8'] . ' and ';
                    }
                }
                $conditions .= '1 = 1';
            }
        }

        // Paginate
        $this->paginate = array (
            'conditions' => $conditions,
            'limit' => 12
        );
        $data = $this->paginate();
        $this->set('games', $data);
        $this->render('/elements/all_games');
    }

    /*
     * Method used to view games recommended.
     */
    function view($id = null) {
        return $this->Game->read(null, $id);
    }

    /*
     * Set rate game. 1 to 5 star.
     */
    function set_rate ($item_id = null, $rate = null) {
        $ts = time();
        return $this->afinimaki->set_rate($this->Session->read('User.email'), $item_id, $rate, $ts);
    }

    /*
     * Estimate rate for each items (games). It value require a lot of rates.
     */
    function estimate_rate($item_id = null) {
        return $this->afinimaki->estimate_rate($this->Session->read('User.email'), $item_id);
    }

    /*
     * AfinimaKi Engine return items recommended for each users.
     */
    function get_recommendations($user_id) {
        $boolean = 0;
        return $this->afinimaki->get_recommendations($user_id, $boolean);
    }

}
?>